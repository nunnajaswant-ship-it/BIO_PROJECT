from Bio import Entrez, SeqIO, pairwise2
from Bio.Seq import Seq
from collections import OrderedDict
import sys

# ============================
# CONFIGURATION
# ============================

Entrez.email = "your_email@example.com"   # REQUIRED BY NCBI

MAX_DOWNLOAD = 2000
MIN_LEN = 90
MAX_LEN = 110
MIN_IDENTITY = 70.0   # % identity cutoff

REFERENCE_SEQ = Seq(
    "PQFSLWKRPVVTAYIEGQPVEVLLDTGADDSIVAGIELGNNYSPKIVGGIGGFINTLEYKNVEIEVLNKKVRATIMTGDT"
)

# ============================
# STEP 1: SEARCH NCBI
# ============================

print("🔍 Searching NCBI for HIV-2 protease sequences...")

query = (
    '"Human immunodeficiency virus 2"[Organism] AND protease'
)

search = Entrez.esearch(
    db="protein",
    term=query,
    retmax=MAX_DOWNLOAD
)
record = Entrez.read(search)
search.close()

ids = record["IdList"]
print(f"Found {len(ids)} sequences")

if len(ids) == 0:
    sys.exit("❌ No sequences found")

# ============================
# STEP 2: FETCH FASTA
# ============================

fetch = Entrez.efetch(
    db="protein",
    id=ids,
    rettype="fasta",
    retmode="text"
)

records = list(SeqIO.parse(fetch, "fasta"))
fetch.close()

print(f"Downloaded {len(records)} raw sequences")

# ============================
# STEP 3: FILTER BY LENGTH
# ============================

length_filtered = [
    rec for rec in records
    if MIN_LEN <= len(rec.seq) <= MAX_LEN
]

print(f"After length filter: {len(length_filtered)}")

# ============================
# ALIGNMENT FUNCTION
# ============================

def identity_percentage(ref, query):
    aln = pairwise2.align.globalms(
        ref, query,
        2, -1, -10, -0.5,
        one_alignment_only=True
    )[0]

    matches = sum(
        1 for a, b in zip(aln.seqA, aln.seqB) if a == b
    )

    return (matches / len(aln.seqA)) * 100

# ============================
# STEP 4: IDENTITY FILTER
# ============================

high_quality = []

for rec in length_filtered:
    pid = identity_percentage(REFERENCE_SEQ, rec.seq)
    if pid >= MIN_IDENTITY:
        rec.annotations["identity"] = pid
        high_quality.append(rec)

print(f"After identity filter (≥{MIN_IDENTITY}%): {len(high_quality)}")

# ============================
# STEP 5: REMOVE REDUNDANCY
# ============================

unique_seqs = OrderedDict()

for rec in high_quality:
    seq_str = str(rec.seq)
    if seq_str not in unique_seqs:
        unique_seqs[seq_str] = rec

final_records = list(unique_seqs.values())

print(f"After redundancy removal: {len(final_records)}")

# ============================
# STEP 6: WRITE FINAL DATASET
# ============================

SeqIO.write(final_records, "HIV2_protease_FINAL.fasta", "fasta")

with open("HIV2_protease_summary.txt", "w") as f:
    f.write(f"Initial download: {len(records)}\n")
    f.write(f"After length filter: {len(length_filtered)}\n")
    f.write(f"After identity filter: {len(high_quality)}\n")
    f.write(f"Final non-redundant set: {len(final_records)}\n")

print("\n✅ FINAL DATASET READY")
print("FASTA: HIV2_protease_FINAL.fasta")
print("Summary: HIV2_protease_summary.txt")
