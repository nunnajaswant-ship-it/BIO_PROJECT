import pandas as pd
import numpy as np

# 1. CONFIGURATION
# Using your local path
INPUT_FILE = r"C:\Users\nunna\OneDrive\Desktop\4th semester\bioPROJECT\DATASET FINAL\HIV2_CLEAN_MASTER_DATASET.fasta"
OUTPUT_EXCEL = "HIV2_Simplified_Mutation_Summary.xlsx"

# The Reference (Wild-Type) Sequence
REF_SEQ = "PQFSLWKRPVVTAYIEGQPVEVLLDTGADDSIVAGIELGNNYSPKIVGGIGGFINTLEYKNVEIEVLNKKVRATIMTGDTTPINIFGRNILTKGLGCTLNF"

# 2. FASTA PARSER (Reads the file into memory)
def parse_fasta(filename):
    sequences = []
    with open(filename, 'r') as f:
        current_id = None
        current_seq = []
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"): continue
            if line.startswith(">"):
                if current_id:
                    sequences.append((current_id, "".join(current_seq)))
                current_id = line[1:]
                current_seq = []
            else:
                current_seq.append(line)
        if current_id:
            sequences.append((current_id, "".join(current_seq)))
    return sequences

# 3. ALIGNMENT ENGINE (Matches sequence to Reference)
def simple_align(ref, target):
    n, m = len(ref), len(target)
    score = np.zeros((n + 1, m + 1))
    match, mismatch, gap = 2, -1, -2
    for i in range(n + 1): score[i][0] = i * gap
    for j in range(m + 1): score[0][j] = j * gap
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            s = match if ref[i-1] == target[j-1] else mismatch
            score[i][j] = max(score[i-1][j-1] + s, score[i-1][j] + gap, score[i][j-1] + gap)
    ar, at, i, j = "", "", n, m
    while i > 0 and j > 0:
        s = match if ref[i-1] == target[j-1] else mismatch
        if score[i][j] == score[i-1][j-1] + s:
            ar, at, i, j = ref[i-1]+ar, target[j-1]+at, i-1, j-1
        elif score[i][j] == score[i-1][j] + gap:
            ar, at, i = ref[i-1]+ar, "-"+at, i-1
        else:
            ar, at, j = "-"+ar, target[j-1]+at, j-1
    while i > 0:
        ar, at, i = ref[i-1]+ar, "-"+at, i-1
    while j > 0:
        ar, at, j = "-"+ar, target[j-1]+at, j-1
    return ar, at

# 4. EXECUTION
print(f"🚀 Loading sequences from: {INPUT_FILE}")
fasta_data = parse_fasta(INPUT_FILE)

print(f"🔍 Finding mutations in {len(fasta_data)} sequences...")
summary_results = []

for seq_id, seq in fasta_data:
    ar, at = simple_align(REF_SEQ, seq.upper())
    mutations = []
    ref_idx = 0
    for r, t in zip(ar, at):
        if r != '-':
            ref_idx += 1
            if t != r and t != '-':
                mutations.append(f"{r}{ref_idx}{t}")
    
    summary_results.append({
        "Sequence ID": seq_id,
        "Sequence": seq,
        "Mutation Count": len(mutations),
        "Mutations": ", ".join(mutations)
    })

# 5. SAVE TO EXCEL
df = pd.DataFrame(summary_results)
df.to_excel(OUTPUT_EXCEL, index=False)
print(f"✨ DONE! Simplified report saved as: {OUTPUT_EXCEL}")
