import pandas as pd
import numpy as np
from Bio import SeqIO

# 1. SETUP: The HIV-2 Protease Reference (Wild-Type)
REF_SEQ = "PQFSLWKRPVVTAYIEGQPVEVLLDTGADDSIVAGIELGNNYSPKIVGGIGGFINTLEYKNVEIEVLNKKVRATIMTGDTTPINIFGRNILTKGLGCTLNF"

# 2. FILE LOCATIONS
INPUT_FILE = r"C:\Users\nunna\OneDrive\Desktop\4th semester\bioPROJECT\DATASET FINAL\HIV2_CLEAN_MASTER_DATASET.fasta"
OUTPUT_EXCEL = "HIV2_Detailed_Mutation_Analysis.xlsx"

def simple_align(ref, target):
    """Aligns target sequence to Reference to find exact mutation positions."""
    n, m = len(ref), len(target)
    score = np.zeros((n + 1, m + 1))
    match, mismatch, gap = 2, -1, -2
    
    for i in range(n + 1): score[i][0] = i * gap
    for j in range(m + 1): score[0][j] = j * gap
    
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            s = match if ref[i-1] == target[j-1] else mismatch
            score[i][j] = max(score[i-1][j-1] + s, score[i-1][j] + gap, score[i][j-1] + gap)
            
    ar, at, i, j = "", "", n, m
    while i > 0 and j > 0:
        s = match if ref[i-1] == target[j-1] else mismatch
        if score[i][j] == score[i-1][j-1] + s:
            ar, at, i, j = ref[i-1]+ar, target[j-1]+at, i-1, j-1
        elif score[i][j] == score[i-1][j] + gap:
            ar, at, i = ref[i-1]+ar, "-"+at, i-1
        else:
            ar, at, j = "-"+ar, target[j-1]+at, j-1
    return ar, at

# --- THE FIX: LOADING THE DATA ---
print(f"📖 Reading sequences...")
fasta_data = []
for record in SeqIO.parse(INPUT_FILE, "fasta"):
    fasta_data.append((record.id, str(record.seq).upper()))

# 3. PROCESSING ENGINE
print(f"🧬 Analyzing {len(fasta_data)} sequences...")
results = []
for seq_id, seq in fasta_data:
    ar, at = simple_align(REF_SEQ, seq)
    mutations = []
    # Initialize position map with Wild-Type residues
    pos_map = {f"P{k}": REF_SEQ[k-1] for k in range(1, len(REF_SEQ)+1)}
    
    ref_idx = 0
    for r, t in zip(ar, at):
        if r != '-':
            ref_idx += 1
            pos_map[f"P{ref_idx}"] = t
            if t != r and t != '-':
                mutations.append(f"{r}{ref_idx}{t}")
    
    # This row has the summary AND the individual positions
    row = {"ID": seq_id, "Total_Muts": len(mutations), "Mut_List": ", ".join(mutations)}
    row.update(pos_map)
    results.append(row)

# 4. EXPORT TO EXCEL
df = pd.DataFrame(results)
df.to_excel(OUTPUT_EXCEL, index=False)
print(f"✅ Mission Accomplished! Check {OUTPUT_EXCEL}")
