import pandas as pd

# 1. THE COMPLETE HIV-2 DATASET (Major + Minor + Consensus Polymorphisms)
# We assign Polymorphisms a score of 0 or 1 so they appear in the "Markers" 
# column without changing the clinical resistance level (High/Low).
perfect_data = [
    # --- Major Resistance (High Score) ---
    ["V32I", "DRV", 15, "Minor"], ["I47A", "DRV", 60, "Major"], ["I47V", "DRV", 60, "Major"],
    ["I50V", "DRV", 60, "Major"], ["I54M", "DRV", 30, "Major"], ["I54L", "DRV", 30, "Major"],
    ["L76V", "DRV", 60, "Major"], ["V82A", "DRV", 30, "Major"], ["V82F", "DRV", 60, "Major"],
    ["I84V", "DRV", 60, "Major"], ["L90M", "DRV", 15, "Major"],
    
    ["V32I", "LPV", 15, "Minor"], ["M46I", "LPV", 15, "Minor"], ["M46L", "LPV", 15, "Minor"],
    ["V47A", "LPV", 60, "Major"], ["I50V", "LPV", 60, "Major"], ["I54M", "LPV", 60, "Major"],
    ["I54L", "LPV", 30, "Major"], ["T56V", "LPV", 30, "Minor"], ["V82A", "LPV", 30, "Major"],
    ["V82F", "LPV", 60, "Major"], ["I84V", "LPV", 60, "Major"], ["L90M", "LPV", 30, "Major"],
    
    ["M46I", "SQV", 15, "Minor"], ["M46L", "SQV", 15, "Minor"], ["I47A", "SQV", 60, "Major"],
    ["I50V", "SQV", 60, "Major"], ["I54M", "SQV", 60, "Major"], ["I54L", "SQV", 30, "Major"],
    ["V82A", "SQV", 30, "Major"], ["V82F", "SQV", 60, "Major"], ["I84V", "SQV", 60, "Major"],
    ["L90M", "SQV", 60, "Major"],
    
    ["M46I", "IDV", 15, "Minor"], ["M46L", "IDV", 15, "Minor"], ["I47A", "IDV", 60, "Major"],
    ["I50V", "IDV", 60, "Major"], ["I54M", "IDV", 60, "Major"], ["I54L", "IDV", 30, "Major"],
    ["V82A", "IDV", 30, "Major"], ["V82F", "IDV", 60, "Major"], ["I84V", "IDV", 60, "Major"],
    ["L90M", "IDV", 30, "Major"],

    # --- Accessory & Compensatory (Multi-drug) ---
    ["A71V", "All", 5, "Accessory"], ["L99F", "All", 5, "Accessory"],

    # --- Consensus Polymorphisms (The "Missing" Data) ---
    # We apply these to "All" drugs with a score of 1 to ensure they are logged.
    ["L57K", "All", 1, "Polymorphism"],
    ["C97M", "All", 1, "Polymorphism"],
    ["T98S", "All", 1, "Polymorphism"],
    ["G94A", "All", 1, "Polymorphism"],
    ["N40S", "All", 1, "Polymorphism"],
    ["K70R", "All", 1, "Polymorphism"],
    ["Y14H", "All", 1, "Polymorphism"]
]

# 2. SAVE MASTER RULES
# Path updated to your local directory structure
OUTPUT_PATH = r"C:\Users\nunna\OneDrive\Desktop\4th semester\bioPROJECT\DATASET FINAL\Mutation–Drug Resistance Mapping\HIV2_PI_RESISTANCE_PERFECT_RULES.csv"
df = pd.DataFrame(perfect_data, columns=["Mutation", "Drug", "Score", "Type"])
df.to_csv(OUTPUT_PATH, index=False)

print(f"✅ UNIFIED Rulebook created at: {OUTPUT_PATH}")
