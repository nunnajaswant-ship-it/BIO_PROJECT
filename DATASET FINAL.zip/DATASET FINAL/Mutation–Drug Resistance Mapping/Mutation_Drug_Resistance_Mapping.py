import pandas as pd
import numpy as np
import os

# ==========================================
# 1. DIRECTORY CONFIGURATION
# ==========================================
# I have used raw strings (r"") to ensure Windows paths work perfectly.
BASE_DIR = r"C:\Users\nunna\OneDrive\Desktop\4th semester\bioPROJECT\DATASET FINAL"
SUMMARY_FILE = os.path.join(BASE_DIR, "Mutation Annotation Dataset", "HIV2_Simplified_Mutation_Summary.xlsx")
RULES_FILE = os.path.join(BASE_DIR, "Mutation–Drug Resistance Mapping", "HIV2_PI_RESISTANCE_PERFECT_RULES.csv")
FINAL_OUTPUT = "HIV2_MASTER_RESISTANCE_REPORT.xlsx"

# ==========================================
# 2. GENERATE THE PERFECT RULEBOOK
# ==========================================
# This data includes Major, Minor, and all common HIV-2 variations (Polymorphisms).
perfect_data = [
    # --- MAJOR MUTATIONS (Score 60: High Impact) ---
    ["V47A", "LPV", 60, "Major"], ["I50V", "LPV", 60, "Major"], ["I50V", "DRV", 60, "Major"],
    ["I54M", "LPV", 60, "Major"], ["I54M", "SQV", 60, "Major"], ["I54M", "DRV", 30, "Major"],
    ["L76V", "DRV", 60, "Major"], ["I82F", "LPV", 60, "Major"], ["I84V", "DRV", 60, "Major"],
    ["L90M", "SQV", 60, "Major"], ["L90M", "LPV", 30, "Major"], ["I47A", "All", 60, "Major"],

    # --- MINOR / ACCESSORY (Score 15-30: Intermediate) ---
    ["V32I", "DRV", 15, "Minor"], ["V32I", "LPV", 15, "Minor"], ["M46I", "IDV", 15, "Minor"],
    ["M46L", "LPV", 15, "Minor"], ["I54L", "LPV", 30, "Minor"], ["T56V", "LPV", 30, "Minor"],
    ["V82A", "IDV", 30, "Minor"], ["A71V", "All", 10, "Minor"], ["L99F", "All", 10, "Minor"],

    # --- CONSENSUS POLYMORPHISMS (Score 1-5: The "Marker" fillers) ---
    # These ensure your "Known_Markers" column is populated for every sequence.
    ["L57K", "All", 5, "Polymorphism"], ["C97M", "All", 5, "Polymorphism"],
    ["T98S", "All", 5, "Polymorphism"], ["G94A", "All", 5, "Polymorphism"],
    ["N40S", "All", 5, "Polymorphism"], ["F101L", "All", 5, "Polymorphism"],
    ["K70R", "All", 5, "Polymorphism"], ["Y14H", "All", 5, "Polymorphism"],
    ["E65K", "All", 5, "Polymorphism"], ["N68G", "All", 5, "Polymorphism"],
    ["S43T", "All", 5, "Polymorphism"], ["F101P", "All", 5, "Polymorphism"],
    ["K7R", "All", 2, "Polymorphism"], ["L67V", "All", 2, "Polymorphism"],
    ["N41D", "All", 2, "Polymorphism"], ["V71I", "All", 2, "Polymorphism"],
    ["K93N", "All", 2, "Polymorphism"], ["G94T", "All", 2, "Polymorphism"],
    ["N61D", "All", 2, "Polymorphism"], ["G17D", "All", 2, "Polymorphism"]
]

# Save the Rules CSV
df_rules_new = pd.DataFrame(perfect_data, columns=["Mutation", "Drug", "Score", "Type"])
os.makedirs(os.path.dirname(RULES_FILE), exist_ok=True)
df_rules_new.to_csv(RULES_FILE, index=False)
print(f"✅ Rulebook updated with {len(perfect_data)} entries.")

# ==========================================
# 3. MAPPING ENGINE
# ==========================================
# Load the 467 sequences summary
df_summary = pd.read_excel(SUMMARY_FILE)

# Build a Scoring Map: {Mutation: {Drug: Score}}
scoring_map = {}
for _, row in df_rules_new.iterrows():
    m = row['Mutation'].strip()
    if m not in scoring_map: scoring_map[m] = {}
    
    # Keyword "All" applies to every PI
    drugs_to_apply = ["DRV", "IDV", "LPV", "SQV"] if row['Drug'] == "All" else [row['Drug']]
    for d in drugs_to_apply:
        scoring_map[m][d] = row['Score']

DRUGS = ["DRV", "IDV", "LPV", "SQV"]

def analyze_sequence(mut_string):
    if pd.isna(mut_string): return {d: "None" for d in DRUGS}, ""
    
    seq_muts = [m.strip() for m in str(mut_string).split(',')]
    scores = {d: 0 for d in DRUGS}
    found_known = []
    
    for m in seq_muts:
        if m in scoring_map:
            found_known.append(m)
            for drug, points in scoring_map[m].items():
                scores[drug] += points
    
    # Clinical Interpretation Logic
    res_labels = {}
    for d in DRUGS:
        s = scores[d]
        if s >= 60: res_labels[d] = "High"
        elif s >= 30: res_labels[d] = "Intermediate"
        elif s >= 15: res_labels[d] = "Low"
        elif s > 0: res_labels[d] = "Accessory/Polymorphic" # Filling the "None" gap
        else: res_labels[d] = "None"
            
    return res_labels, ", ".join(sorted(list(set(found_known))))

# ==========================================
# 4. EXECUTION & EXPORT
# ==========================================
print(f"🔬 Processing {len(df_summary)} sequences...")
results = []
markers_col = []

for _, row in df_summary.iterrows():
    labels, markers = analyze_sequence(row['Mutations'])
    results.append(labels)
    markers_col.append(markers)

df_final = pd.concat([df_summary, pd.DataFrame(results)], axis=1)
df_final['Known_Resistance_Markers'] = markers_col

# Clean up column order
final_cols = ['Sequence ID', 'Mutation Count', 'Mutations', 'Known_Resistance_Markers'] + DRUGS + ['Sequence']
df_final[final_cols].to_excel(FINAL_OUTPUT, index=False)

print(f"✅ FINAL REPORT SAVED: {FINAL_OUTPUT}")
