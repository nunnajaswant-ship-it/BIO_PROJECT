from Bio import SeqIO
from collections import OrderedDict

# Define your input files
input_files = ["C:/Users/nunna/OneDrive/Desktop/4th semester/bioPROJECT/DATASET FINAL/HIV 2 PI/HIV2_protease_FINAL.fasta", "C:/Users/nunna/OneDrive/Desktop/4th semester/bioPROJECT/DATASET FINAL/HIV 2 PI from NCBI DNA TO PROTIEN/HIV2_ULTIMATE_DATASET.fasta"]
output_file = "HIV2_CLEAN_MASTER_DATASET.fasta"

unique_records = OrderedDict()
duplicate_count = 0

print("🧹 Starting the Great Clean-up...")

for file in input_files:
    try:
        for record in SeqIO.parse(file, "fasta"):
            # Convert sequence to string for exact matching
            seq_str = str(record.seq).upper()
            
            if seq_str not in unique_records:
                unique_records[seq_str] = record
            else:
                duplicate_count += 1
    except FileNotFoundError:
        print(f"⚠️ Warning: {file} not found, skipping.")

# Write the final clean file
SeqIO.write(unique_records.values(), output_file, "fasta")

print("-" * 30)
print(f"✅ CLEAN-UP COMPLETE!")
print(f"Total Unique Sequences Kept: {len(unique_records)}")
print(f"Total Redundant Sequences Removed: {duplicate_count}")
print(f"Final File Saved as: {output_file}")
print("-" * 30)
