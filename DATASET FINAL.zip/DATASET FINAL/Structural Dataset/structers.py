import pandas as pd
import os

# ==========================================
# 1. AMINO ACID PROPERTY DATABASE
# ==========================================
# Hydrophobicity (Kyte-Doolittle), Molecular Weight, and pI
AA_PROPS = {
    'A': {'hydro': 1.8, 'mw': 89.1, 'pi': 6.0},  'R': {'hydro': -4.5, 'mw': 174.2, 'pi': 10.76},
    'N': {'hydro': -3.5, 'mw': 132.1, 'pi': 5.41}, 'D': {'hydro': -3.5, 'mw': 133.1, 'pi': 2.77},
    'C': {'hydro': 2.5, 'mw': 121.2, 'pi': 5.07},  'E': {'hydro': -3.5, 'mw': 147.1, 'pi': 3.22},
    'Q': {'hydro': -3.5, 'mw': 146.1, 'pi': 5.65}, 'G': {'hydro': -0.4, 'mw': 75.1, 'pi': 5.97},
    'H': {'hydro': -3.2, 'mw': 155.2, 'pi': 7.59}, 'I': {'hydro': 4.5, 'mw': 131.2, 'pi': 6.02},
    'L': {'hydro': 3.8, 'mw': 131.2, 'pi': 5.98},  'K': {'hydro': -3.9, 'mw': 146.2, 'pi': 9.74},
    'M': {'hydro': 1.9, 'mw': 149.2, 'pi': 5.74},  'F': {'hydro': 2.8, 'mw': 165.2, 'pi': 5.48},
    'P': {'hydro': -1.6, 'mw': 115.1, 'pi': 6.3},   'S': {'hydro': -0.8, 'mw': 105.1, 'pi': 5.68},
    'T': {'hydro': -0.7, 'mw': 119.1, 'pi': 5.6},   'W': {'hydro': -0.9, 'mw': 204.2, 'pi': 5.89},
    'Y': {'hydro': -1.3, 'mw': 181.2, 'pi': 5.66},  'V': {'hydro': 4.2, 'mw': 117.1, 'pi': 5.96}
}

# 2. LOAD YOUR PERFECT DATA
INPUT_FILE = "C:/Users/nunna/OneDrive/Desktop/4th semester/bioPROJECT/DATASET FINAL/Mutation–Drug Resistance Mapping/HIV2_MASTER_RESISTANCE_REPORT.xlsx"
OUTPUT_FILE = "HIV2_FINAL_FEATURE_MATRIX.xlsx"
df = pd.read_excel(INPUT_FILE)

def extract_physico_features(mut_list_str):
    if pd.isna(mut_list_str) or mut_list_str == "":
        return 0, 0, 0 # No change for wild-type
    
    muts = [m.strip() for m in str(mut_list_str).split(',')]
    total_hydro_change = 0
    total_mw_change = 0
    total_pi_change = 0
    
    for m in muts:
        try:
            # Parse notation like 'V47A'
            wt_aa = m[0]
            mut_aa = m[-1]
            
            if wt_aa in AA_PROPS and mut_aa in AA_PROPS:
                total_hydro_change += (AA_PROPS[mut_aa]['hydro'] - AA_PROPS[wt_aa]['hydro'])
                total_mw_change += (AA_PROPS[mut_aa]['mw'] - AA_PROPS[wt_aa]['mw'])
                total_pi_change += (AA_PROPS[mut_aa]['pi'] - AA_PROPS[wt_aa]['pi'])
        except:
            continue
            
    return total_hydro_change, total_mw_change, total_pi_change

# 3. APPLY TO DATAFRAME
print("🧪 Calculating Structural & Sequence Features...")
features = df['Mutations'].apply(extract_physico_features)
df[['Hydro_Delta', 'MW_Delta', 'pI_Delta']] = pd.DataFrame(features.tolist(), index=df.index)

# 4. SAVE FINAL MATRIX
df.to_excel(OUTPUT_FILE, index=False)
print(f"✅ Task 3 Complete. Features saved in: {OUTPUT_FILE}")
