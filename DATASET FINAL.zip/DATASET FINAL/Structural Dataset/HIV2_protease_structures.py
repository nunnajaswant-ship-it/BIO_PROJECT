import pandas as pd
import numpy as np
import os

# ==========================================
# 1. CONFIGURATION
# ==========================================
# Update these names if your files are named differently
INPUT_FILE = "HIV2_FINAL_FEATURE_MATRIX.xlsx" 
PDB_FILE = "3S45.pdb"  # Using the most precise HIV-2 Darunavir structure
LIGAND_CODE = "478"    # This is the PDB code for the drug in 3S45
OUTPUT_FILE = "HIV2_FINAL_MASTER_FEATURE_MATRIX.xlsx"

# ==========================================
# 2. PDB PROCESSING ENGINE
# ==========================================
def get_pocket_distance_map(pdb_path, ligand_id):
    """Extracts the distance of every residue 1-101 to the drug center."""
    ligand_atoms = []
    ca_atoms = {} # {residue_number: [list of coordinates for all chains]}

    if not os.path.exists(pdb_path):
        print(f"❌ Error: {pdb_path} not found!")
        return None

    with open(pdb_path, 'r') as f:
        for line in f:
            # Get drug coordinates
            if line.startswith("HETATM") and ligand_id in line[17:21]:
                x, y, z = float(line[30:38]), float(line[38:46]), float(line[46:54])
                ligand_atoms.append(np.array([x, y, z]))
            
            # Get Protein backbone coordinates (C-alpha)
            if line.startswith("ATOM") and line[12:16].strip() == "CA":
                res_num = int(line[22:26])
                x, y, z = float(line[30:38]), float(line[38:46]), float(line[46:54])
                if res_num not in ca_atoms:
                    ca_atoms[res_num] = []
                ca_atoms[res_num].append(np.array([x, y, z]))

    if not ligand_atoms:
        print(f"❌ Error: Ligand {ligand_id} not found in {pdb_path}")
        return None

    # Calculate the geometric center of the drug
    ligand_center = np.mean(ligand_atoms, axis=0)

    # Map residue numbers to the minimum distance to the drug
    dist_map = {}
    for res_num, coords_list in ca_atoms.items():
        # Min distance across all chains (A or B)
        dists = [np.linalg.norm(c - ligand_center) for c in coords_list]
        dist_map[res_num] = min(dists)
        
    return dist_map

# ==========================================
# 3. FEATURE EXTRACTION
# ==========================================
def run_task_3():
    print("🧬 Starting Task 3: Structural Feature Extraction...")
    
    # Load PDB Distances
    dist_map = get_pocket_distance_map(PDB_FILE, LIGAND_CODE)
    if not dist_map: return

    # Load your existing Feature Matrix
    try:
        df = pd.read_excel(INPUT_FILE)
    except:
        df = pd.read_csv(INPUT_FILE.replace(".xlsx", ".csv"))

    def calculate_3d_metrics(mut_string):
        if pd.isna(mut_string) or str(mut_string).strip() == "":
            return 0.0, 0.0
        
        muts = [m.strip() for m in str(mut_string).split(',')]
        seq_distances = []
        
        for m in muts:
            try:
                # Extract position: 'V47A' -> 47
                pos = int(''.join(filter(str.isdigit, m)))
                if pos in dist_map:
                    seq_distances.append(dist_map[pos])
                elif pos > 99: # Handle C-terminal tail 100-101
                    seq_distances.append(dist_map[99] + (pos - 99) * 2.5)
            except:
                continue
        
        if not seq_distances:
            return 0.0, 0.0
        
        return np.mean(seq_distances), np.min(seq_distances)

    # Apply to all 467 sequences
    print("📏 Calculating distances from mutations to binding pocket...")
    results = df['Mutations'].apply(calculate_3d_metrics)
    df[['Avg_Dist_to_Pocket', 'Min_Dist_to_Pocket']] = pd.DataFrame(results.tolist(), index=df.index)

    # Save the final result
    df.to_excel(OUTPUT_FILE, index=False)
    print(f"✅ Success! Task 3 is complete. Final matrix saved as: {OUTPUT_FILE}")

if __name__ == "__main__":
    run_task_3()
