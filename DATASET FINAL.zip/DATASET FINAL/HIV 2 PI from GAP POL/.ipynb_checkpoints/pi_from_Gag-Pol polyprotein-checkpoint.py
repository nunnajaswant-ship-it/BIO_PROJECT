import os
from Bio import Entrez, SeqIO, Align
from Bio.Seq import Seq
from collections import OrderedDict

# ============================
# CONFIGURATION
# ============================
Entrez.email = "your_email@example.com" 
# This query targets the 'hidden' protease sequences in parent genes
SEARCH_QUERY = '("Human immunodeficiency virus 2"[Organism]) AND (pol OR "gag-pol" OR "polyprotein")'
MAX_DOWNLOAD = 5000 
# The 1IVP Reference (99 AA)
REF_SEQ = "PQFSLWKRPVVTAYIEGQPVEVLLDTGADDSIVAGIELGNNYSPKIVGGIGGFINTLEYKNVEIEVLNKKVRATIMTGDTTPINIFGRNILTKGLGCTLNF"

# ============================
# 1. NCBI SEARCH
# ============================
print(f"🔍 Searching NCBI for HIV-2 Polyproteins...")
search_handle = Entrez.esearch(db="protein", term=SEARCH_QUERY, retmax=MAX_DOWNLOAD)
search_results = Entrez.read(search_handle)
ids = search_results["IdList"]
print(f"Found {len(ids)} IDs. Downloading...")

# ============================
# 2. DOWNLOAD & SLICE
# ============================
unique_proteases = OrderedDict()
aligner = Align.PairwiseAligner()
aligner.mode = 'local' # CRITICAL: Finds the short protease in the long polyprotein

print("✂️ Slicing Protease domains from Polyproteins...")

# Fetching in chunks to prevent NCBI timeouts
chunk_size = 100
for i in range(0, len(ids), chunk_size):
    chunk = ids[i:i+chunk_size]
    fetch_handle = Entrez.efetch(db="protein", id=chunk, rettype="fasta", retmode="text")
    records = list(SeqIO.parse(fetch_handle, "fasta"))
    
    for rec in records:
        seq_str = str(rec.seq).upper()
        
        # Look for the 'Heart' of the protease (DTG/DSG)
        if "DTG" in seq_str or "DSG" in seq_str:
            alignments = aligner.align(seq_str, REF_SEQ)
            
            if len(alignments) > 0:
                best = alignments[0]
                try:
                    # Get coordinates of the match
                    start, end = best.aligned[0][0]
                    extracted_str = seq_str[start:end]
                    
                    # Length check: Protease must be ~99 AA
                    if 90 <= len(extracted_str) <= 110:
                        if extracted_str not in unique_proteases:
                            rec.seq = Seq(extracted_str)
                            unique_proteases[extracted_str] = rec
                except (IndexError, AttributeError):
                    continue
    print(f"Progress: {i + len(chunk)}/{len(ids)} processed...")

# ============================
# 3. SAVE RESULTS
# ============================
final_list = list(unique_proteases.values())
output_file = "HIV2_NCBI_EXPANDED_DATASET.fasta"
SeqIO.write(final_list, output_file, "fasta")

print("\n" + "="*30)
print(f"✅ SUCCESS!")
print(f"Total Unique Proteases Extracted: {len(final_list)}")
print(f"File Saved: {output_file}")
print("="*30)
