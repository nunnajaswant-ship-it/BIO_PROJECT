import pandas as pd
import re
import os

print("🚀 INITIATING FINAL HIV-2 RESISTANCE ANALYSIS...")

def analyze_enzyme(enzyme_name, file_name, motifs):
    print(f"⏳ Scanning {enzyme_name}...")
    if not os.path.exists(file_name):
        print(f"❌ ERROR: I cannot find '{file_name}'. Make sure it's in this folder!")
        return

    df = pd.read_csv(file_name)
    results = []

    for index, row in df.iterrows():
        seq = str(row.get("Sequence", ""))
        seq_id = row.get("Sequence ID", f"Seq_{index}")
        
        found_mutations = []
        # Look for the exact biological resistance markers
        for mut_name, pattern in motifs.items():
            if re.search(pattern, seq):
                found_mutations.append(mut_name)
        
        status = "Resistant" if found_mutations else "Sensitive (Wild-Type)"
        
        results.append({
            "Sequence ID": seq_id,
            "Enzyme": enzyme_name,
            "Resistance Level": status,
            "Mutations Found": ", ".join(found_mutations) if found_mutations else "None"
        })

    # Save the Final Report
    res_df = pd.DataFrame(results)
    out_name = f"FINAL_{enzyme_name.upper()}_RESISTANCE_REPORT.csv"
    res_df.to_csv(out_name, index=False)
    print(f"✅ DONE! Saved to -> {out_name}")

# The "Known Rules" (The science part is done for you)
rt_motifs = {
    "M184V (High NRTI Resistance)": "YVDD", 
    "Q151M (Multi-NRTI Resistance)": "LPM",
    "K65R (Tenofovir Resistance)": "KRS",
    "Intrinsic NNRTI Resistance (Y181I/Y188L)": "IDI" # HIV-2 natural resistance
}

ini_motifs = {
    "N155H (Raltegravir Resistance)": "HLQ", 
    "G140S (Dolutegravir Resistance)": "SQP",
    "Q148H (Dolutegravir Resistance)": "HVT"
}

# Run the analyzer
analyze_enzyme("Reverse_Transcriptase", "HIV2_RT_PROPER_DATASET.csv", rt_motifs)
analyze_enzyme("Integrase", "HIV2_INI_PROPER_DATASET.csv", ini_motifs)

print("\n🎉 ALL FINISHED! You have completed the HIV-2 Genotype-Phenotype Project. Go rest!")
