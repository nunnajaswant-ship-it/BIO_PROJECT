import pandas as pd
from Bio import Entrez, SeqIO
import os

# ⚠️ IMPORTANT: Put your email here so NCBI doesn't block your connection
Entrez.email = "nunnajaswant@gmail.com" 

def fetch_and_filter_hiv2(enzyme_name, min_len, max_len, filename_prefix):
    print(f"📡 Searching NCBI for HIV-2 '{enzyme_name}' sequences...")
    
    # 1. Exact Database Search Term
    search_term = f'("Human immunodeficiency virus 2"[Organism] AND "{enzyme_name}"[All Fields])'
    
    try:
        # Search NCBI Protein Database
        search_handle = Entrez.esearch(db="protein", term=search_term, retmax=2000)
        record = Entrez.read(search_handle)
        id_list = record["IdList"]
        search_handle.close()
        
        print(f"🔍 Found {len(id_list)} total raw records. Fetching sequences from NCBI (this takes a moment)...")
        
        # 2. Fetch the actual sequence strings
        fetch_handle = Entrez.efetch(db="protein", id=id_list, rettype="fasta", retmode="text")
        sequences = list(SeqIO.parse(fetch_handle, "fasta"))
        fetch_handle.close()
        
        # 3. Quality Control (Filter by correct enzyme length)
        valid_records = []
        for seq in sequences:
            # We only keep sequences that are complete and not fragments
            if min_len <= len(seq.seq) <= max_len:
                valid_records.append(seq)
                
        print(f"✅ Quality Control Passed: Kept {len(valid_records)} high-quality sequences (Length between {min_len}-{max_len} aa).")
        
        # 4. Save to FASTA (This is what you paste into the Stanford Website)
        fasta_filename = f"{filename_prefix}_CLEAN_DATASET.fasta"
        SeqIO.write(valid_records, fasta_filename, "fasta")
        
        # 5. Save to CSV (This is for your internal Project Feature Matrix)
        csv_data = [{
            "Sequence ID": r.id, 
            "Description": r.description, 
            "Sequence": str(r.seq), 
            "Length": len(r.seq)
        } for r in valid_records]
        
        df = pd.DataFrame(csv_data)
        csv_filename = f"{filename_prefix}_PROPER_DATASET.csv"
        df.to_csv(csv_filename, index=False)
        
        print(f"📁 Successfully saved to: \n  -> {fasta_filename}\n  -> {csv_filename}\n")
        
    except Exception as e:
        print(f"❌ Error fetching {enzyme_name}: {e}\n")

# ==========================================
# EXECUTION BLOCK (Runs both tasks at once)
# ==========================================

print("🚀 STARTING VIRAL GENOTYPE PIPELINE...\n" + "="*40)

# TASK A: Get Reverse Transcriptase (Target Length: ~560 amino acids)
fetch_and_filter_hiv2(
    enzyme_name="reverse transcriptase", 
    min_len=540, 
    max_len=580, 
    filename_prefix="HIV2_RT"
)

# TASK B: Get Integrase (Target Length: ~288 amino acids)
fetch_and_filter_hiv2(
    enzyme_name="integrase", 
    min_len=280, 
    max_len=300, 
    filename_prefix="HIV2_INI"
)

print("="*40 + "\n🎉 ALL DONE! Your full HIV-2 Genome Dataset is ready.")
