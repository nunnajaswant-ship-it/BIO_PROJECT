import os
from Bio import Entrez, SeqIO, Align
from Bio.Seq import Seq
from collections import OrderedDict

# ============================
# CONFIGURATION
# ============================
Entrez.email = "your_email@example.com" 
# This query searches the Nucleotide database for everything HIV-2 related
SEARCH_QUERY = '("Human immunodeficiency virus 2"[Organism]) AND (genome OR pol OR protease)'
MAX_DOWNLOAD = 3000 # Increased to get more potential genomic matches
REF_SEQ = "PQFSLWKRPVVTAYIEGQPVEVLLDTGADDSIVAGIELGNNYSPKIVGGIGGFINTLEYKNVEIEVLNKKVRATIMTGDTTPINIFGRNILTKGLGCTLNF"

# ============================
# 1. SEARCH NUCLEOTIDE
# ============================
print(f"🌐 Searching NCBI Nucleotide for HIV-2 Genomes/Genes...")
search_handle = Entrez.esearch(db="nucleotide", term=SEARCH_QUERY, retmax=MAX_DOWNLOAD)
search_results = Entrez.read(search_handle)
ids = search_results["IdList"]
print(f"Found {len(ids)} DNA records. Starting extraction...")

# ============================
# 2. EXTRACTION ENGINE
# ============================
unique_proteases = OrderedDict()
aligner = Align.PairwiseAligner()
aligner.mode = 'local'

# Process in chunks to avoid server errors
chunk_size = 50
for i in range(0, len(ids), chunk_size):
    chunk = ids[i:i+chunk_size]
    # Fetching in 'gb' format because it contains the protein translations
    fetch_handle = Entrez.efetch(db="nucleotide", id=chunk, rettype="gb", retmode="text")
    records = list(SeqIO.read_gb(fetch_handle)) if chunk_size == 1 else list(SeqIO.parse(fetch_handle, "gb"))
    
    for rec in records:
        # Scan through the features (CDS) of the DNA record
        for feature in rec.features:
            if feature.type == "CDS":
                # Look for translations associated with Protease or Pol
                product = str(feature.qualifiers.get("product", [""])[0]).lower()
                note = str(feature.qualifiers.get("note", [""])[0]).lower()
                
                if "protease" in product or "pol" in product or "protease" in note or "pol" in note:
                    translation = feature.qualifiers.get("translation", [None])[0]
                    
                    if translation:
                        translation = translation.upper()
                        
                        # Slicing Logic
                        # If it's just the protease (approx 99 AA), take it
                        if 90 <= len(translation) <= 110:
                            if translation not in unique_proteases:
                                unique_proteases[translation] = translation
                        
                        # If it's a long polyprotein (Gag-Pol), slice the 99 AA out
                        elif len(translation) > 200:
                            alignments = aligner.align(translation, REF_SEQ)
                            if alignments:
                                best = alignments[0]
                                start, end = best.aligned[0][0]
                                sliced = translation[start:end]
                                if 90 <= len(sliced) <= 110 and sliced not in unique_proteases:
                                    unique_proteases[sliced] = sliced
                                    
    print(f"Progress: {i + len(chunk)}/{len(ids)} | Current Unique Count: {len(unique_proteases)}")

# ============================
# 3. SAVE THE MASTER DATASET
# ============================
output_file = "HIV2_ULTIMATE_DATASET.fasta"
with open(output_file, "w") as f:
    for i, seq in enumerate(unique_proteases.values()):
        f.write(f">HIV2_PR_{i+1}\n{seq}\n")

print("\n" + "="*30)
print(f"✅ MISSION ACCOMPLISHED!")
print(f"Final Non-Redundant Count: {len(unique_proteases)}")
print(f"File Saved: {output_file}")
print("="*30)
