from Bio import Entrez, SeqIO, pairwise2
from Bio.Seq import Seq
from collections import OrderedDict
import sys

# ============================
# CONFIGURATION
# ============================
# Use your actual email here for NCBI
Entrez.email = "your_email@example.com"   

MAX_DOWNLOAD = 10000
MIN_LEN = 90
MAX_LEN = 110
MIN_IDENTITY = 70.0   # % identity cutoff

# HXB2 is the standard HIV-1 Protease Reference Sequence (99 AA)
REFERENCE_SEQ = Seq(
    "PQITLWQRPLVTIKIGGQLKEALLDTGADDTVLEEMNLPGRWKPKMIGGIGGFIKVRQYDQILIEICGHKAIGTVLVGPTPVNIIGRNLLTQIGCTLNF"
)

# ============================
# STEP 1: SEARCH NCBI
# ============================
print("🔍 Searching NCBI for HIV-1 protease sequences...")

# Changed search term to "Human immunodeficiency virus 1"
query = (
    '\"Human immunodeficiency virus 1\"[Organism] AND protease'
)

search = Entrez.esearch(
    db="protein",
    term=query,
    retmax=MAX_DOWNLOAD
)
record = Entrez.read(search)
search.close()

ids = record["IdList"]
print(f"Found {len(ids)} sequences")

if len(ids) == 0:
    sys.exit("❌ No sequences found")

# ============================
# STEP 2: FETCH FASTA
# ============================
print(f"📥 Fetching {len(ids)} sequences...")
handle = Entrez.efetch(db="protein", id=ids, rettype="fasta", retmode="text")
records = list(SeqIO.parse(handle, "fasta"))
handle.close()

print(f"Fetched {len(records)} sequences")

# ============================
# STEP 3: FILTER BY LENGTH
# ============================
length_filtered = [
    rec for rec in records if MIN_LEN <= len(rec.seq) <= MAX_LEN
]
print(f"After length filter ({MIN_LEN}-{MAX_LEN}): {len(length_filtered)}")

# ============================
# STEP 4: IDENTITY FILTER & REDUNDANCY
# ============================
def identity_percentage(seq1, seq2):
    # Uses global alignment to check how similar the sequence is to HXB2
    alignments = pairwise2.align.globalxx(seq1, seq2, one_alignment_only=True)
    if not alignments:
        return 0
    score = alignments[0][2]
    return (score / len(seq1)) * 100

high_quality = []
unique_seqs = OrderedDict()

print("🧬 Checking identity and removing duplicates...")
for rec in length_filtered:
    pid = identity_percentage(REFERENCE_SEQ, rec.seq)
    if pid >= MIN_IDENTITY:
        seq_str = str(rec.seq)
        if seq_str not in unique_seqs:
            rec.annotations["identity"] = pid
            unique_seqs[seq_str] = rec

final_records = list(unique_seqs.values())
print(f"Final high-quality unique HIV-1 sequences: {len(final_records)}")

# ============================
# STEP 5: WRITE FINAL DATASET
# ============================
SeqIO.write(final_records, "HIV1_protease_NEGATIVE_CONTROL.fasta", "fasta")

with open("HIV1_protease_metadata.csv", "w") as f:
    f.write("Accession,Length,Identity_to_HXB2\n")
    for rec in final_records:
        f.write(f"{rec.id},{len(rec.seq)},{rec.annotations['identity']:.2f}\n")

print("✅ Files saved: HIV1_protease_NEGATIVE_CONTROL.fasta and HIV1_protease_metadata.csv")
