import pandas as pd

# Define the dataset based on HIV-2 specific clinical efficacy
drug_data = [
    {"Drug_Name": "Darunavir", "Abbreviation": "DRV", "Class": "PI", "HIV2_Relevance": "High"},
    {"Drug_Name": "Lopinavir", "Abbreviation": "LPV", "Class": "PI", "HIV2_Relevance": "High"},
    {"Drug_Name": "Saquinavir", "Abbreviation": "SQV", "Class": "PI", "HIV2_Relevance": "High"},
    {"Drug_Name": "Indinavir", "Abbreviation": "IDV", "Class": "PI", "HIV2_Relevance": "Low"},
    {"Drug_Name": "Amprenavir", "Abbreviation": "APV", "Class": "PI", "HIV2_Relevance": "Low"},
    {"Drug_Name": "Atazanavir", "Abbreviation": "ATV", "Class": "PI", "HIV2_Relevance": "Low"},
    {"Drug_Name": "Nelfinavir", "Abbreviation": "NFV", "Class": "PI", "HIV2_Relevance": "Ineffective"},
    {"Drug_Name": "Tipranavir", "Abbreviation": "TPV", "Class": "PI", "HIV2_Relevance": "Ineffective"}
]

# Create DataFrame
df_drugs = pd.DataFrame(drug_data)

# Save to CSV
output_file = "HIV2_PI_drug_list.csv"
df_drugs.to_csv(output_file, index=False)

print(f"✅ Dataset #3 Complete.")
print(f"File saved: {output_file}")
print(df_drugs)
